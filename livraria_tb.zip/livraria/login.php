<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<title>Login</title>
<link rel="stylesheet" type="text/css" href="footer.css">
<link rel="stylesheet" type="text/css" href="livraria.css">
<link rel="stylesheet" type="text/css" href="cadastro.css">

</head>

<body>
        <nav class="topnav">
            <a href="login.php">LOGIN</a>
            <a href="cadastropessoa.php">CADASTRAR-SE</a>
            <a href="livraria.html">PAGINA INICIAL</a>
            <a href="livro.php">LIVROS</a>
        </nav>
  <div style="margin-top: 50px; align-content: center"></div>
  <div id="formulario">
    <table>
      <form action="" method="post" class="back form">
      <p id="titulo">Fazer Login:</p>
        <tr><td></td><td><input type="text" name="email" placeholder="E-mail"></td></tr>
        <tr><td></td><td><input type="text" name="senha" placeholder="Senha"></td></tr>
        <tr><td colspan=2><input type="submit" name="Enviar" value="Enviar" id="botao"></td></tr>
    </table>
  </form>
  </div>
  <div>
    
    <?php
    include('conexao.php');
    //eu acho que eu tenho que por isso aqui
    if (isset($_POST['logar'])) {
      $email = $_POST['email'];
      $senha = $_POST['senha'];
      $db=mysqli_select_db($conexao,$banco);
      $result = mysqli_query($conexao,"select senha from usuario where email = '$email'");
        while(res =  mysqli_fetch_assoc($result)){
               $confere = res['senha'];
        }
      if($confere==$senha){
        $conta = array(
          0 => $_POST['email'],
          1 => $_POST['senha']
        );
          setcookie("login", $conta ,time()+7*24*3600);
          echo"Login realizado com sucesso!";
          echo $_COOKIE["login"][0];
          echo $_COOKIE["login"][1];
          echo"<a href='livraria.html'>OK</a>";     
      }
      else{
          echo "Sua senha ou endereço de e-mail está incorreto";
      }
  }
    ?></div>
</body>

    <footer id="">
        <p style="font-family: 'Poiret One', cursive; font-size: 16px;">Desenvolvido por Enrico Benvenuti, Samuel Kamohara e Suriel Jacobsen</p>
        <a href="https://www.instagram.com/livraria_cultura/" target="_blank">
            <img class="red" id="is" src="C:\Users\surie\Desktop\insta.jpg"/>
        </a>
        <a href="https://www.facebook.com/livrariacultura/" target="_blank">
            <img class="red" id="fb" src="‪C:\Users\surie\Desktop\faceb.jpg"/>
        </a>
        <a href="https://twitter.com/livrariacultura" target="_blank">
			<img class="red" id="tw" src="‪C:\Users\surie\Desktop\tt.jpg"/>
        </a>
    </footer>   
</html>