<!DOCTYPE html>
<html>
<head>
<meta charset=utf-8" />
<title>Cadastrolivro</title>
<link rel="stylesheet" type="text/css" href="footer.css">
<link rel="stylesheet" type="text/css" href="livraria.css">
<link rel="stylesheet" type="text/css" href="cadastro.css">
</head>

<body>
        <nav class="topnav">
            <a href="login.php">LOGIN</a>
            <a href="cadastropessoa.php">CADASTRAR-SE</a>
            <a href="livraria.html">PAGINA INICIAL</a>
            <a href="livro.php">LIVROS</a>
        </nav>
<div style="margin-top: 50px; align-content: center"></div>
<div id="formulario">
    <table>
    <form action="" method="post" enctype="multipart/form-data">
    <p id="titulo">Cadastre um livro!</p>
    <tr><td></td><td><input type="text" name="titulo" placeholder="Titulo"></td></tr>
    <tr><td></td><td><input type="text" name="autor" placeholder="Autor"></td></tr>
    <tr><td></td><td><input type="text" name="editora" placeholder="Editora"></td></tr>
    <tr><td></td><td><input type="text" name="sinopse" placeholder="Sinopse"></td></tr>
    <tr><td></td><td><input type="text" name="capa" placeholder="Capa"></td></tr>

<tr><td colspan=2><input type="submit" name="Incluir" value="Incluir" id="botao"></td></tr>
<tr><td colspan=2><input type="submit" name="Limpar" value="Limpar" id="botao"></td></tr>
<tr><td colspan=2><input type="submit" name="Mostrar" value="Mostrar" id="botao"></td></tr>
    </table>
<BR>
    <table>
Registro a ser excluido:
<tr><td></td><td><input type="text" name="Registro" placeholder="Registro"></td></tr>
<tr><td colspan=2><input type="submit" name="Excluir" value="Excluir" id="botao"></td></tr>
    </table>
</form>
</div>

<div>

<?php
    $titulo=isset($_POST['titulo'])?$_POST['titulo']:null;  
    $autor=isset($_POST['autor'])?$_POST['autor']:null; 
    $editora=isset($_POST['editora'])?$_POST['editora']:null; 
    $capa=isset($_FILES['capa']['name'])? $_FILES['capa']['name']:null; 
    $sinopse=isset($_POST['sinopse'])?$_POST['sinopse']:null;
	
    include('conexao.php');
    //print_r($_FILES);       
    if(isset($_POST['Incluir'])){
        //código para incluir
        $db=mysqli_select_db($conexao,$banco);
        $grava=mysqli_query($conexao,"insert 
        into cadastrolivro(titulo,autor,editora,capa,sinopse)values('$titulo',
        '$autor','$editora','$capa','$sinopse')");
        if($grava==true){
            echo"Cadastro realizado com sucesso!!";
            move_uploaded_file($_FILES['capa']['tmp_name'],"uploads/".$_FILES['capa']['name']);
          
        }
        else{
            echo "Impossível incluir!!";
        }                                       
    }
    if(isset($_POST['Mostrar'])){
        //código para mostrar
        $db=mysqli_select_db($conexao,$banco);
        $mostra=mysqli_query($conexao,"select * from cadastrolivro 
        order by codigo");
        $num_linhas=mysqli_num_rows($mostra);
        echo"<table border=\"1\">";
        echo"
			<td>Código</td>
	          <td>Titulo</td>
			   <td>Autor</td>
			   <td>Editora</td>
			   <td>Sinopse</td>
			   <td>Capa</td>
			    <td>Alteração</td></tr>";
        for($i=0;$i<$num_linhas;$i++){
            $mostra_tabela=mysqli_fetch_array($mostra);
		    $codigo= $mostra_tabela['codigo'];
            // echo"<tr><td>Excluir $codigo</td>";
            echo "<td>$codigo</td>";
            $titulo=$mostra_tabela['titulo'];
            echo"<td>$titulo</td>";
            $autor=$mostra_tabela['autor'];
            echo "<td>$autor</td>";
            $editora=$mostra_tabela['editora'];
            echo "<td>$editora</td>";
			 $sinopse=$mostra_tabela['sinopse'];
            echo "<td>$sinopse</td>";
            $capa=$mostra_tabela['capa'];
            echo "<td><img src='uploads/$capa' width='100' height='100'></td>";
            echo"<td><a href='altera.php?codigo=$codigo'>Alteração</a></td>";
            echo "</tr>";    
        }
        echo "</table>";

    }
    if(isset($_POST['Excluir'])){
        $codigo=$_POST['registro'];
		
        $db=mysqli_select_db($conexao,$banco);
        $resultado = mysqli_query ($conexao,"select * from cadastrolivro where codigo=$codigo");
        if ($resultado==false) {
             echo "Erro na query";
             exit;
         }
        if (mysqli_num_rows($resultado) != 0) {
             mysqli_query ($conexao,"delete from cadastrolivro where codigo=$codigo");
             echo "<script>alert(\"Registro excluído com sucesso!\")
             </script>";
         }
         else {
             echo "<script>alert(\"Registro inexistente!\")</script>";
         } 
    }    
?></div>
</body>
    <footer id="">
        <p style="font-family: 'Poiret One', cursive; font-size: 16px;">Desenvolvido por Enrico Benvenuti, Samuel Kamohara e Suriel Jacobsen</p>
        <a href="https://www.instagram.com/livraria_cultura/" target="_blank">
            <img class="red" id="is" src="C:\Users\surie\Desktop\insta.jpg"/>
        </a>
        <a href="https://www.facebook.com/livrariacultura/" target="_blank">
            <img class="red" id="fb" src="‪C:\Users\surie\Desktop\faceb.jpg"/>
        </a>
        <a href="https://twitter.com/livrariacultura" target="_blank">
			<img class="red" id="tw" src="‪C:\Users\surie\Desktop\tt.jpg"/>
        </a>
    </footer>   
</html>