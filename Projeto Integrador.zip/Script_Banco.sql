CREATE DATABASE bd_projeto;
USE bd_projeto;

CREATE TABLE Configuracao(
id_configuracao BIGINT NOT NULL UNIQUE AUTO_INCREMENT,
mudar_senha VARCHAR(20),
mudar_nome VARCHAR(50),
mudar_email VARCHAR(30),
PRIMARY KEY(id_configuracao)
);

CREATE TABLE Usuario(
id_usuario BIGINT NOT NULL UNIQUE AUTO_INCREMENT,
email VARCHAR(30) NOT NULL UNIQUE,
nome VARCHAR(30) NOT NULL,
senha VARCHAR(20) NOT NULL,
tipo_de_usuario VARCHAR(10) NOT NULL,
PRIMARY KEY(id_usuario),
id_configuracao BIGINT NOT NULL,
FOREIGN KEY(id_configuracao) REFERENCES Configuracao(id_configuracao)
);

CREATE TABLE Gerencia(
id_gerencia BIGINT NOT NULL UNIQUE AUTO_INCREMENT,
PRIMARY KEY(id_gerencia),
id_usuario BIGINT NOT NULL,
FOREIGN KEY(id_usuario) REFERENCES Usuario(id_usuario)
);

CREATE TABLE Tarefa(
id_tarefa BIGINT NOT NULL UNIQUE AUTO_INCREMENT,
data_realizacao DATE,
data_previsao DATE,
descricao_tarefa VARCHAR(80) NOT NULL,
categoria VARCHAR(50),
PRIMARY KEY(id_tarefa)
);

CREATE TABLE Usuario_Tarefa(
id_usuario_tarefa BIGINT NOT NULL UNIQUE AUTO_INCREMENT,
PRIMARY KEY(id_usuario_tarefa),
id_tarefa BIGINT NOT NULL,
FOREIGN KEY(id_tarefa) REFERENCES Tarefa(id_tarefa),
id_usuario BIGINT NOT NULL,
FOREIGN KEY(id_usuario) REFERENCES Usuario(id_usuario)
);